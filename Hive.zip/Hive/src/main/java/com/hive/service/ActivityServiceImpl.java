package com.hive.service;
import com.hive.entity.Activity;
import com.hive.dao.ActivityDao;
import com.hive.entity.Activity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ActivityServiceImpl implements ActivityService {
    @Autowired
    private ActivityDao activityDao;
    @Override
    public Boolean addActivity(Activity activity) {
        activityDao.insertActivity(activity);
        return true;
    }

    @Override
    public List<Activity> queryAllActivity() {
        List<Activity> activityList = activityDao.selectAllActivity();
        return  activityList;
    }
    @Override
    public Boolean removeActivityById(Integer id) {
        activityDao.deleteActivityById(id);
        return true;
    }

    @Override
    public List<Activity> queryActivityById(Integer id) {
        List<Activity> activityList = activityDao.selectActivityById(id);
        return activityList;
    }

    @Override
    public Boolean updateActivity(Activity activity) {
        return activityDao.updateActivity(activity);
     // return  true;
    }

    @Override
    public Activity Queryone(Integer id) {
        return  activityDao.queryActivityById( id);
    }

    @Override
    public Activity NoAproveAll() {
        return activityDao.NoApprove();
    }


}
