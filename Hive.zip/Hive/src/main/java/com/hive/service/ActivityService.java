package com.hive.service;

import com.hive.entity.Activity;

import java.util.List;

public interface ActivityService {
    Boolean addActivity(Activity activity);
    List<Activity> queryAllActivity();
    Boolean removeActivityById(Integer id);
    List<Activity> queryActivityById(Integer id);
    Boolean updateActivity(Activity activity);
    Activity Queryone(Integer id);
    Activity NoAproveAll( );
}