package com.hive.dao;
import com.hive.entity.Activity;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface ActivityDao {
    //对于mysql查询的方法返回值怎么写？
    //两种情况1.本次查询有多条2.本次查询最多只有一条数据
    //查所有 <>-泛型是指当前list集合中要保存什么类型的数据
    //只需要给方法定义合适的返回值类型，mybatis会自动将查询结果封装为你定义的返回值
    @Select("SELECT * FROM activity" )
    List<Activity> selectAllActivity();
    //List<Activity> selectAllActivity();//接口中的方法
    //根据id查询-能够具有相查哪个id就查哪个id的功能
    //那么我们需要告诉mybatis，把查询条件以形参的形式定义在方法中
    //为了让形参中的参数能够可变的应用在sql语句中，需要使用#{形参名}
    //根据name查询，可能多条数据，使用集合
    //根据id删除没有返回值，使用void
   @Delete("Delete  from Activity where id=#{id} ")
    void deleteActivityById(Integer id);
    @Insert("insert into activity values (#{id},#{club_id},#{start_time},#{end_time},#{name},#{localtion},#{requre},#{pay_or_not},#{condition})")
    void  insertActivity(Activity activity);
    @Select("SELECT * FROM activity WHERE id = #{id} ")
    List<Activity> selectActivityById(Integer id);
    @Update("UPDATE activity SET club_id=#{club_id}, start_time=#{start_time}, end_time=#{end_time}, name=#{name}," +
            " localtion=#{localtion}, requre=#{requre}, pay_or_not=#{pay_or_not}," +
            " `condition`=#{condition} WHERE id=#{id}")
    Boolean updateActivity(Activity activity);
    @Select("SELECT * FROM activity WHERE id = #{id} ")
   Activity queryActivityById(Integer id);
    @Select("SELECT * FROM activity WHERE `condition` = '待审' ")
    Activity NoApprove();
}