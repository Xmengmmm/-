package com.hive.controller;

import com.hive.entity.Activity;
import com.hive.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("activity")
public class ActivityController {
    @Autowired
    private ActivityService activityService;
    @RequestMapping("addActivity")
    //当接收的数据是一个对象时，无需单独定义每一个参数，只需要在形参中定义你想接收的对象即可
    public  Boolean addActivity(Activity activity){
        Boolean result=activityService.addActivity(activity);
        return result;
    }
    @RequestMapping("queryAllActivity")
public List<Activity> queryAllActivity(){
        List<Activity> activityList = activityService.queryAllActivity();
        return activityList;
    }
    @RequestMapping("removeActivityById")
    public Boolean removeActivity(Integer id){
        Boolean result = activityService.removeActivityById(id);
        return result;
    }
    @RequestMapping("queryActivityById")
    public List<Activity> queryActivityById(Integer id){
        return activityService.queryActivityById(id);

    }
    @RequestMapping(value = "updateActivity")
    public Boolean updateActivity(Activity activity){
        System.out.println(activity);
        return activityService.updateActivity(activity);
    }
    @RequestMapping("queryone")
        public Activity Queryone(Integer id){
        return   activityService.Queryone(id);

}
@RequestMapping("noAproveAll")
public Activity NoAproveAll(String condition){
        return activityService.NoAproveAll();
}
}

